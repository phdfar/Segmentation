from .embedding_loss import EmbeddingLoss
from .cross_entropy import CrossEntropyLoss
